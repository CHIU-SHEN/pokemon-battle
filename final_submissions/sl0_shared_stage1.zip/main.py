from __future__ import annotations
import os
import sys
from typing import Any

for _path in (os.getcwd(), "/kaggle_simulations/agent"):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from cg.api import Observation, to_observation_class
from agent.fallback import is_legal_action, safe_action
from agent.parser import GameLedger, parse_observation
from agent.rules import choose_action

LEDGER = GameLedger()
POLICY = None


def read_deck_csv():
    for root in (os.getcwd(), "/kaggle_simulations/agent"):
        path = os.path.join(root, "deck.csv")
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as stream:
                deck = [int(line.strip()) for line in stream if line.strip()]
            if len(deck) == 60:
                return deck
    raise FileNotFoundError("deck.csv")


def get_policy():
    global POLICY
    if POLICY is None:
        from model_runtime import SL0Policy
        POLICY = SL0Policy(read_deck_csv())
    return POLICY


def agent(obs_dict):
    if obs_dict is None:
        return read_deck_csv()
    try:
        obs: Observation = to_observation_class(obs_dict)
        if obs.select is None:
            return read_deck_csv()
        parsed = parse_observation(obs_dict)
        LEDGER.update(parsed)
        try:
            action = get_policy().choose(parsed)
            if is_legal_action(obs.select, action):
                return action
        except Exception:
            pass
        action = choose_action(parsed)
        if is_legal_action(obs.select, action):
            return action
        return safe_action(obs.select, parsed, prefer_empty=False)
    except Exception:
        try:
            obs = to_observation_class(obs_dict)
            return safe_action(obs.select, prefer_empty=False) if obs.select is not None else read_deck_csv()
        except Exception:
            return []
